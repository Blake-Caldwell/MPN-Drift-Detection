## MPN time series forecasting model for the following activities: 

### 1. Trucking
### 2. Bogging
### 3. Jumbo
### 4. Long hole drilling (lhdrilling)

## Run the main.ipynb file to generate forecast and backtest files.

### input_folder = 'bdm1_shiftly_processed'

##### """ Contains datasets used in the project. """