import pickle
import numpy as np
import pandas as pd
from gluonts.dataset.pandas import PandasDataset
from gluonts.torch.model.deepar import DeepAREstimator

class DeepARTimeseries():
    def __init__(self):
        pass

    def train(
            self,
            train_df: pd.DataFrame,
            date_column: str,
            target_column: str,
            forecast_length: int,
            n_epochs: int = 100,
            batch_size: int = 16,
            num_batches_per_epoch: int = 8,
            lr: float = 0.01,
            num_layers: int = 3,
            freq: str = 'W',
            save_to: str = 'DeepAr.pkl'

    ):
        
        for col_name in train_df.columns[1:]:
            val = train_df[col_name].values
            if col_name == target_column:
                target_min = val.min()
                target_max = val.max()
            val = (val - val.min()) / (val.max() - val.min())
            train_df[col_name] = val
        train_df['item'] = 0
        train_ds = PandasDataset.from_long_dataframe(train_df, target=target_column, item_id='item', 
                                                    timestamp=date_column, freq=freq)
        estimator = DeepAREstimator(freq=freq, prediction_length=forecast_length, num_layers=num_layers, num_batches_per_epoch=num_batches_per_epoch,
                                    batch_size=batch_size, lr=lr,
                                    trainer_kwargs={'accelerator': 'cpu', 'max_epochs':n_epochs})
        predictor = estimator.train(train_ds, num_workers=2)

        with open(save_to, 'wb') as file:
            pickle.dump([predictor, train_ds, target_min, target_max], file)
    
    def load_model(
            self,
            model_path: str
    ):
        with open(model_path, 'rb') as file:
            model_data = pickle.load(file)
        return model_data
    
    def predict(
            self,
            model_path: str,
            q1: float = 0.1,
            q2: float = 0.9
    ):
        model_data = self.load_model(model_path)
        predictor, forecast_ds, target_min, target_max = model_data
        pred = list(predictor.predict(forecast_ds))
        item = pred[0]
        pred = item.samples.mean(axis=0)
        pred_low = np.percentile(item.samples, q1*100, axis=0)
        pred_high = np.percentile(item.samples, q2*100, axis=0)
    
        pred_df = pd.DataFrame()
        pred_df['pred'] = (pred * (target_max-target_min)) + target_min
        pred_df['pred_low'] = (pred_low * (target_max-target_min)) + target_min
        pred_df['pred_high'] = (pred_high * (target_max-target_min)) + target_min
        return pred_df