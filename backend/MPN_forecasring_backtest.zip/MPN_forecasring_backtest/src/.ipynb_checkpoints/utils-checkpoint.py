import pandas as pd
import numpy as np
import os
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import plotly.express as px

from src.lstm_ts import LSTMTimeseries
from src import MPN_Bogging, MPN_LHDrill, MPN_Trucking, MPN_Jumbo
from src.preprocessing import preprocessing
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

new_dates_prediction = True
date_column = 'DATE'


def train_models(df, target_column, activity, site_name, num_test_prediction):
    total_pred_df = pd.DataFrame()
    models_name = set()
    for i in range(not new_dates_prediction, num_test_prediction+1):
        logging.info(f'{i+1} Backtest period, {20 * "+"} LSTM model for {activity} in {site_name} Site {20 * "+"}')
        # print(f'{i}, {20 * "+" } LSTM model for {activity} in {site_name} Site {20 * "+" }')

        #### train and test split ###
        train_idx_max = None if i == 0 else -i*forecast_length
        train_df = df[:train_idx_max]
        train_df = train_df[train_df[date_column] <= train_df[date_column].iloc[-1]]

        ### make target smoother
        train_df[target_column] = train_df[target_column].ewm(alpha=0.4).mean()

        # define test date
        test_dates = pd.date_range(start=train_df[date_column].iloc[-1], periods=forecast_length+1, freq=freq)[1:]
        test_dates = pd.DataFrame({date_column:test_dates})
        pred_df = pd.DataFrame({date_column:test_dates[date_column]})

        ### LSTM train and prediction
        feature_importance = False #True if i == num_test_prediction else False
        lstm = LSTMTimeseries()
        _ = lstm.train(train_df.copy(deep=True), target_column=target_column, date_column=date_column,
                        lookback=input_chunk_length, prediction_length=forecast_length, 
                        save_to=f'{models}/lstm_{site_name}_{activity}.pkl', num_epochs=1068, lr=0.00595,
                        num_layers=2, hidden_dim=43, feature_importance=feature_importance)
        lstm_preds = lstm.predict(model_path=f'{models}/lstm_{site_name}_{activity}.pkl')
        pred_df['LSTM'] = lstm_preds['pred']
        pred_df['LSTM_low'] = lstm_preds['pred_low']
        pred_df['LSTM_high'] = lstm_preds['pred_high']
        models_name.add('LSTM')

        # concatenate predictions
        if len(total_pred_df) == 0:
            for col_name in pred_df.keys():
                total_pred_df[col_name] = []
        total_pred_df = pd.concat([pred_df, total_pred_df])

    total_pred_df = total_pred_df.reset_index(drop=True)

    models_name = list(models_name)

    return total_pred_df, models_name

def plot_prediction(total_pred_df, models_name, target_column, activity, site_name, num_test_prediction):
    ### show predictions
    fig = make_subplots(rows=2, cols=1, subplot_titles=(f'{activity}_{site_name}', 'Total of 12 Weeks'))
    
    fig.add_trace(go.Scatter(x=df[date_column], y=df[target_column], 
                                name='actual', mode='lines',
                                marker_color=px.colors.qualitative.Alphabet[0]), row=1, col=1)
    fig.add_trace(go.Scatter(x=[df[date_column].iloc[-forecast_length*num_test_prediction],
                                df[date_column].iloc[-forecast_length*num_test_prediction]],
                                y=[df[target_column].max(),df[target_column].min()],
                                line=dict(dash='dash', color='black'),text=["train and test spliter"],
                                textposition="top center", name='spliter', mode='lines+text'), row=1, col=1)
    c = 1
    for col_name in models_name:
        fig.add_trace(go.Scatter(x=total_pred_df[date_column], y=total_pred_df[col_name], 
                                name=f'{col_name}_mean', mode='lines',
                                marker_color=px.colors.qualitative.Alphabet[c]), row=1, col=1)
        fig.add_trace(go.Scatter(x=total_pred_df[date_column], y=total_pred_df[f'{col_name}_low'], 
                                name=f'{col_name}_low', mode='lines', 
                                line=dict(width=0),
                                showlegend=False,
                                marker_color=px.colors.qualitative.Alphabet[c]), row=1, col=1)
        fig.add_trace(go.Scatter(x=total_pred_df[date_column], y=total_pred_df[f'{col_name}_high'], 
                                name=f'{col_name}_uncertrainty', mode='lines',fill='tonexty',line=dict(width=0),
                                marker_color=px.colors.qualitative.Alphabet[c]), row=1, col=1)
        c += 1

    # show bars
    if new_dates_prediction:
        total_pred_df = total_pred_df[:-12]
    total_pred_df['actual'] = df[target_column][-len(total_pred_df):].to_numpy()

    total_pred_df = pd.concat([pd.DataFrame(index=[0]), total_pred_df], ignore_index=True)
    total_pred_df = total_pred_df.set_index('DATE')
    total_pred_df2 = total_pred_df.rolling(12, step=12).sum()[1:]
    total_pred_df2.reset_index(inplace=True)

    fig.add_trace(go.Bar(x=total_pred_df2[date_column] ,y=total_pred_df2['actual'].to_numpy(), 
                        name='Actual, total of 12 weeks',
                        marker_color=px.colors.qualitative.Alphabet[0]), row=2, col=1)
    c = 1
    for col_name in models_name:
        pred = total_pred_df2[col_name].to_numpy()
        mae = 100 * (np.abs(pred - total_pred_df2.actual.values) / total_pred_df2.actual.values)
        mae[mae == np.inf] = 100
        mae = np.mean(mae)
        fig.add_trace(go.Bar(x=total_pred_df2[date_column] ,y=pred, 
                                    name=f'{col_name}, total of 12 weeks, mean_error={round(mae, 1)}%',
                                    marker_color=px.colors.qualitative.Alphabet[c]), row=2, col=1)
        c += 1
    fig.update_layout(width=1500, height=800, legend_traceorder="normal")
    fig.write_html(results + f"/{activity + '_' + site_name}.html")
    fig.show()