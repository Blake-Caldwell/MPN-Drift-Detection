from darts.models import NBEATSModel
import pandas as pd
from darts.dataprocessing.transformers import Scaler
from darts import TimeSeries
import numpy as np
from darts.utils.likelihood_models import LaplaceLikelihood
import pickle
import torch

class NBEATSTimeseries:
    def __init__(self):
        self.model = None

    def train(
            self,
            train_df: pd.DataFrame,
            date_column: str,
            input_chunk_length: int,
            forecast_length: int,
            n_epochs: int = 200,
            batch_size: int = 400,
            save_to: str = 'NBEATS.pkl'
    ):
        
        model = NBEATSModel(
                        input_chunk_length=input_chunk_length,
                        output_chunk_length=forecast_length,
                        generic_architecture=True,
                        num_stacks=10,
                        num_blocks=1,
                        num_layers=4,
                        layer_widths=512,
                        n_epochs=n_epochs,
                        nr_epochs_val_period=1,
                        batch_size=batch_size,
                        model_name="nbeats_run",
                        likelihood=LaplaceLikelihood(prior_b=0.1),
                        )
        
        scaler = Scaler()
        train_series = scaler.fit_transform(TimeSeries.from_dataframe(train_df, date_column, 
                                                                           train_df.columns[1:]
                                                                        )).astype(np.float32)
        model.fit(train_series)
        model.save(save_to)
        self.model = model

        with open(save_to[:-4]+'_scaler.pkl', 'wb') as file:
            pickle.dump(scaler, file)

    def load_model(self, model_path):
        model = NBEATSModel.load(model_path)
        with open(model_path[:-4]+'_scaler.pkl', 'rb') as file:
            scaler = pickle.load(file)
        return model, scaler


    def predict(
            self, 
            forecast_length: int, 
            target_column: str, 
            model_path: str, 
            q1: float = 0.2,
            q2: float = 0.8
        ):
        model, scaler = self.load_model(model_path)
        pred = self.model.predict(forecast_length, num_samples=100)
        pred = scaler.inverse_transform(pred)
        
        pred_df = pd.DataFrame()
        pred_df['pred'] = pred[target_column].mean().values()[:,0]
        pred_df['pred_low'] = pred[target_column].quantile_timeseries(q1).values()[:,0]
        pred_df['pred_high'] = pred[target_column].quantile_timeseries(q2).values()[:,0]
        return pred_df